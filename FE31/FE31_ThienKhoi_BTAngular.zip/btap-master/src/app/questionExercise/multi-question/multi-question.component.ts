import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { IAnsQuestionItem } from '../../models/answerList';

@Component({
  selector: 'app-multi-question',
  templateUrl: './multi-question.component.html',
  styleUrls: ['./multi-question.component.scss']
})
export class MultiQuestionComponent implements OnInit {
  @Input() question;
  @Output() ansEmitter = new EventEmitter();
  answer:IAnsQuestionItem = {
    questionID:'',
    answer:{
      content:'',
      exact: false,
    }
  };
  

  constructor() { }

  ngOnInit() {
  }

  handleAns(e){
    const ansArr = [...this.question.answers];
    const index = ansArr.findIndex(item=>item.content===e.target.value);
    this.answer.questionID = this.question._id;
    this.answer.answer.content = e.target.value;
    this.answer.answer.exact = ansArr[index].exact;
    this.ansEmitter.emit(this.answer);
  }

}
