import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { IAnsQuestionItem } from 'src/app/models/answerList';

@Component({
  selector: 'app-ans-question',
  templateUrl: './ans-question.component.html',
  styleUrls: ['./ans-question.component.scss']
})
export class AnsQuestionComponent implements OnInit {
  @Input() question;
  @Output() ansEmitter = new EventEmitter();
  answer:IAnsQuestionItem = {
    questionID:'',
    answer:{
      content:'',
      exact: false,
    }
  };

  constructor() { }

  ngOnInit() {
  }

  handleAns(ans){
    if(this.question.answers[0].content === ans){
      this.answer.questionID = this.question._id;
      this.answer.answer.content = ans;
      this.answer.answer.exact = true;
      this.ansEmitter.emit(this.answer);
     }
     else{
      this.answer.questionID = this.question._id;
      this.answer.answer.content = ans;
      this.answer.answer.exact = false;
      this.ansEmitter.emit(this.answer);
     }
  }

}
