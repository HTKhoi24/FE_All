import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnsQuestionComponent } from './ans-question.component';

describe('AnsQuestionComponent', () => {
  let component: AnsQuestionComponent;
  let fixture: ComponentFixture<AnsQuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnsQuestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnsQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
