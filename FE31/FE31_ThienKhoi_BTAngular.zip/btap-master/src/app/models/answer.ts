export interface IAns {
    content: string;
    exact: boolean;
}