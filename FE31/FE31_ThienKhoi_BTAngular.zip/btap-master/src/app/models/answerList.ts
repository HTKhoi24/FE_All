import { IAns } from './answer';

export interface IAnsQuestionItem{
    questionID: string;
    answer: IAns
}