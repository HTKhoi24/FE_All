import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ExerciseIndexComponent } from './QuestionExercise/exercise-index/exercise-index.component';
import { MultiQuestionComponent } from './QuestionExercise/multi-question/multi-question.component';
import { AnsQuestionComponent } from './QuestionExercise/ans-question/ans-question.component';

@NgModule({
  declarations: [
    AppComponent,
    ExerciseIndexComponent,
    MultiQuestionComponent,
    AnsQuestionComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
