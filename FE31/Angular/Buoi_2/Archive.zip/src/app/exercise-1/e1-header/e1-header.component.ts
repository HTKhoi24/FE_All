import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e1-header',
  templateUrl: './e1-header.component.html',
  styleUrls: ['./e1-header.component.scss']
})
export class E1HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
