import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e1-index',
  templateUrl: './e1-index.component.html',
  styleUrls: ['./e1-index.component.scss']
})
export class E1IndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
