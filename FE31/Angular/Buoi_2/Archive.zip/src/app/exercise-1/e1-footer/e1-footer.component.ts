import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e1-footer',
  templateUrl: './e1-footer.component.html',
  styleUrls: ['./e1-footer.component.scss']
})
export class E1FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
