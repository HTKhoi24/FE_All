import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e1-sidebar',
  templateUrl: './e1-sidebar.component.html',
  styleUrls: ['./e1-sidebar.component.scss']
})
export class E1SidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
