import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e1-content',
  templateUrl: './e1-content.component.html',
  styleUrls: ['./e1-content.component.scss']
})
export class E1ContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
