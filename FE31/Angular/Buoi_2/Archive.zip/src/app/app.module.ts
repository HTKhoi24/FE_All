import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { DemoComponent } from "./demoComponent/Demo.component";
import { E1IndexComponent } from "./exercise-1/e1-index/e1-index.component";
import { E1HeaderComponent } from "./exercise-1/e1-header/e1-header.component";
import { E1ContentComponent } from "./exercise-1/e1-content/e1-content.component";
import { E1SidebarComponent } from "./exercise-1/e1-sidebar/e1-sidebar.component";
import { E1FooterComponent } from "./exercise-1/e1-footer/e1-footer.component";
import { DemoOnewayComponent } from "./demoDatabinding/demo-oneway/demo-oneway.component";
import { FormsModule } from "@angular/forms";
import { DemoDirectiveComponent } from './DemoDirective/demo-directive/demo-directive.component';
import { ExerciseDirectiveComponent } from './DemoDirective/exercise-directive/exercise-directive.component';
import { ProductManagementComponent } from './DemoDirective/product-management/product-management.component';

@NgModule({
  declarations: [
    AppComponent,
    DemoComponent,
    E1IndexComponent,
    E1HeaderComponent,
    E1ContentComponent,
    E1SidebarComponent,
    E1FooterComponent,
    DemoOnewayComponent,
    DemoDirectiveComponent,
    ExerciseDirectiveComponent,
    ProductManagementComponent
  ],

  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
