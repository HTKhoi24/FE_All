import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-child',
  templateUrl: './demo-child.component.html',
  styleUrls: ['./demo-child.component.scss']
})
export class DemoChildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
