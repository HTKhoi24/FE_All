import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thong-tin-lien-he',
  templateUrl: './thong-tin-lien-he.component.html',
  styleUrls: ['./thong-tin-lien-he.component.scss']
})
export class ThongTinLienHeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
