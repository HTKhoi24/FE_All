import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-lien-he',
  templateUrl: './form-lien-he.component.html',
  styleUrls: ['./form-lien-he.component.scss']
})
export class FormLienHeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
