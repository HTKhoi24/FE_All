import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-lauout',
  templateUrl: './home-lauout.component.html',
  styleUrls: ['./home-lauout.component.scss']
})
export class HomeLauoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
