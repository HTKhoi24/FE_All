import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tran-chi-tiet',
  templateUrl: './tran-chi-tiet.component.html',
  styleUrls: ['./tran-chi-tiet.component.scss']
})
export class TranChiTietComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
