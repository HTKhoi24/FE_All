import { IAnswer } from './answer';

export interface IAnsList{
    QuestionId:string;
    answer:IAnswer;
}