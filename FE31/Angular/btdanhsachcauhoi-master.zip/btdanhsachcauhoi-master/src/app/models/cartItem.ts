import { Product } from './shoppingProduct';

export interface CartItem{
    product: Product
    quantity:number
}