export interface Product{
    id:number
    name:string
    discription:string
    price:number
    inventory:number
    rating:number;
    image:string;
}