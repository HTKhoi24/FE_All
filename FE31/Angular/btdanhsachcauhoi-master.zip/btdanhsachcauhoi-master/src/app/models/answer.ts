export interface IAnswer{
    content:string;
    exact:boolean
}