export interface IMovie{
    id:string;
    name:string;
    image:string;
    discription:string;
}