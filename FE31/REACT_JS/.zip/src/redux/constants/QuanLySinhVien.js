export const THEM_SINH_VIEN = "THEM_SINH_VIEN";
export const SUA_SINH_VIEN = "SUA_SINH_VIEN";
export const XOA_SINH_VIEN = "XOA_SINH_VIEN";
export const CHON_SINH_VIEN = "CHON_SINH_VIEN";
export const TOGGLE_MODAL = "TOGGLE_MODAL";
