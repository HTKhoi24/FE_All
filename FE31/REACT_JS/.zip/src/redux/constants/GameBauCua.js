export const TANG_CUOC = "TANG_CUOC";
export const GIAM_CUOC = "GIAM_CUOC";
export const CHOI_GAME = "CHOI_GAME";
