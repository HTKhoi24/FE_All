const initialState = {
    listCourses: [],
    currentPage: 1,
    totalPage: 0,
    courseDetail: {}
}