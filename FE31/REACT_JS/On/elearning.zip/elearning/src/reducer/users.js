// Lưu thông tin tất cả user dùng trong admin
const initialState = {
    listUsers: [],
    currentPage: 1,
    totalPage: 0,
    userDetail: {}
}