function Album(){
    this.linkAnh = "";
    this.tenAlbum = "";
    this.noiDungAlbum = "";
}